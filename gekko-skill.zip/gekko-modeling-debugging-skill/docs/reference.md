# GEKKO Assistant Reference

GEKKO is a Python package for optimization and machine learning with algebraic, differential-algebraic, dynamic, and mixed-integer models. Use this reference to build, review, debug, and run GEKKO models consistently.

## 1. Assistant workflow

When helping with GEKKO:

1. Classify the task.
   - Algebraic equation solve
   - Steady-state optimization / nonlinear programming
   - Mixed-integer programming / MINLP
   - Dynamic simulation
   - Parameter estimation / regression
   - Moving horizon estimation
   - Model predictive control / dynamic optimization
   - Machine learning model import or GEKKO `brain`
2. Choose the right variable classes.
3. Choose `IMODE` and solver.
4. Write a minimal model first.
5. Add objectives and tuning options.
6. Run locally with visible output while debugging.
7. Interpret solver status and output files.
8. Scale up only after the small model is feasible and interpretable.

## 2. Minimal GEKKO model anatomy

```python
from gekko import GEKKO

m = GEKKO(remote=False)

x = m.Var(value=1, lb=0)
y = m.Var(value=2)

m.Equation(y == x**2 + 1)
m.Minimize((y - 4)**2)

m.options.IMODE = 3
m.options.SOLVER = 3

m.solve(disp=False)

print(x.value[0], y.value[0])
```

Use `remote=False` for examples and local debugging. Use `remote=True` when the user intentionally wants the public APMonitor server or a configured APMonitor server.

## 3. Model values and variable classes

| Class | Use for | Optimizer changes it? | Dynamic behavior |
|---|---|---:|---|
| `m.Const(value)` | Fixed scalar constants | No | Constant |
| `m.Param(value)` | Fixed or time-varying inputs/data | No | Scalar or vector over `m.time` |
| `m.Var(value, lb, ub)` | General unknowns/states | Yes | Value at each time point |
| `m.Intermediate(expr)` | Reused algebraic expressions | Computed from expression | Recomputed as expression |
| `m.FV(value, lb, ub)` | Fitted or optimized scalar parameter | Yes when `STATUS=1` | One value over horizon/data set |
| `m.MV(value, lb, ub)` | Manipulated variable/control/input decision | Yes when `STATUS=1` | Can vary over horizon |
| `m.SV(value)` | State variable with measurement support | Yes | State over horizon |
| `m.CV(value)` | Controlled/measured variable for objectives | Yes | State/output over horizon |

Rules of thumb:

- Use `Param` for known inputs and data vectors.
- Use `Var` for unknown states or algebraic values.
- Use `FV` for a fitted constant parameter, such as a kinetic coefficient.
- Use `MV` for optimized time-varying inputs in control or dynamic optimization.
- Use `CV` for measured outputs in regression, estimation, MHE, or controlled outputs in MPC.
- Use `integer=True` only when a discrete decision is required; add bounds.

## 4. Equations, objectives, and expressions

Use:

```python
m.Equation(lhs == rhs)
m.Equations([eq1, eq2])
m.Minimize(expr)
m.Maximize(expr)
m.Obj(expr)
```

Important:

- Multiple objectives are added together.
- `m.Maximize(obj)` is equivalent to minimizing `-obj`; the reported `OBJFCNVAL` is in the minimized objective convention.
- Use `m.Intermediate()` for repeated expressions to improve readability and model generation.
- Use GEKKO math functions inside GEKKO expressions: `m.exp`, `m.log`, `m.sin`, `m.cos`, `m.sqrt`, `m.tanh`.
- Do not use Python `if`, `max`, `min`, `abs`, or NumPy functions on GEKKO variables. They execute before the solver sees the symbolic expression.

## 5. IMODE decision table

| Task | `m.options.IMODE` | Notes |
|---|---:|---|
| Steady-state simulation / square algebraic solve | 1 | No objective needed if square and feasible |
| Steady-state parameter update / regression | 2 | Use `FV.STATUS=1`, measured `CV.FSTATUS=1` |
| Steady-state optimization / RTO | 3 | General NLP/MINLP optimization |
| Dynamic simultaneous simulation | 4 | Define `m.time`, derivatives with `dt()` |
| Moving horizon estimation / dynamic estimation | 5 | Measurements via `CV.FSTATUS=1` |
| Dynamic optimization / MPC simultaneous control | 6 | `MV.STATUS=1`, `CV.STATUS=1` |
| Dynamic sequential simulation | 7 | Sequential alternative to 4 |
| Dynamic sequential estimation | 8 | Sequential alternative to 5 |
| Dynamic sequential control | 9 | Sequential alternative to 6 |

For dynamic modes, define `m.time` before solving:

```python
import numpy as np
m.time = np.linspace(0, 10, 51)
x = m.Var(value=1)
m.Equation(x.dt() == -x)
m.options.IMODE = 4
```

## 6. Solver choice

| Solver setting | Solver | Use for |
|---:|---|---|
| `m.options.SOLVER = 1` | APOPT | Mixed-integer problems, MINLP, many control problems |
| `m.options.SOLVER = 2` | BPOPT | Some nonlinear programming problems |
| `m.options.SOLVER = 3` | IPOPT | Smooth continuous NLPs, common default choice |

Guidance:

- For integer variables, logical `if3`, `abs3`, `max3`, `min3`, or `sos1`, use APOPT (`SOLVER=1`).
- For smooth continuous models, IPOPT (`SOLVER=3`) is often appropriate.
- If one solver fails, try another only after checking model feasibility, scaling, bounds, and initial guesses.
- Add solver options as a list of strings:

```python
m.solver_options = [
    'max_iter 500',
    'minlp_gap_tol 0.01',
]
```

Only use options supported by the selected solver.

## 7. Dynamic models

A dynamic model needs:

- `m.time`
- variables with initial values
- differential equations using `x.dt()`
- an `IMODE` greater than 3

Example:

```python
m = GEKKO(remote=False)
m.time = [0, 1, 2, 3, 4, 5]

x = m.Var(value=5)
k = m.Param(value=0.4)

m.Equation(x.dt() == -k * x)
m.options.IMODE = 4
m.solve(disp=False)
```

Common dynamic mistakes:

- Forgetting `m.time`
- Using `IMODE=3` with `dt()`
- Initializing dynamic vectors with wrong length
- Treating `x.value` as a scalar after solve when it is a list over time
- Over-constraining the initial condition; use `fixed_initial=False` only intentionally

## 8. Estimation and regression

Steady-state regression:

```python
m = GEKKO(remote=False)
x = m.Param(value=x_data)

a = m.FV(value=0.5, lb=0)
a.STATUS = 1

y = m.CV(value=y_data)
y.FSTATUS = 1

m.Equation(y == model_expression)
m.options.IMODE = 2
m.solve(disp=False)
```

Dynamic estimation / MHE:

- Use `IMODE=5` or `8`.
- Use measured outputs with `CV.FSTATUS=1`.
- Use fitted parameters with `FV.STATUS=1` or time-varying estimates with `MV.STATUS=1`.
- Prefer a small horizon until measurements, time arrays, and model equations are verified.

## 9. MPC and dynamic optimization

Core MPC pattern:

```python
u = m.MV(value=0, lb=0, ub=100)
u.STATUS = 1
u.DCOST = 0.1
u.DMAX = 5

y = m.CV(value=0)
y.STATUS = 1
y.FSTATUS = 1
y.SP = 10
y.TAU = 5
y.TR_INIT = 2

m.options.IMODE = 6
m.options.CV_TYPE = 2
```

For `CV_TYPE=1`, use setpoint bands (`SPHI`, `SPLO`) and weights (`WSPHI`, `WSPLO`). For `CV_TYPE=2`, use `SP` and `WSP`.

## 10. Discrete and logical decisions

GEKKO solvers are gradient-based. Avoid non-smooth Python conditionals on GEKKO variables.

Use smooth/complementarity forms:

```python
y = m.if2(condition, value_if_negative, value_if_nonnegative)
z = m.abs2(x)
```

Use binary/integer forms when an exact discrete switch is required:

```python
m.options.SOLVER = 1
y = m.if3(condition, value_if_negative, value_if_nonnegative)
b = m.Var(integer=True, lb=0, ub=1)
```

Use `m.sos1([values])` to choose one value from a discrete list.

## 11. Running models

Debug-friendly run:

```python
m = GEKKO(remote=False)
# build model...
m.options.DIAGLEVEL = 1
m.solve(disp=True, debug=1)
print("model folder:", m.path)
```

Production-style run:

```python
m.solve(disp=False)
```

Useful outputs:

```python
print(m.options.APPSTATUS)
print(m.options.SOLVESTATUS)
print(m.options.OBJFCNVAL)
print(m.options.SOLVETIME)
print(x.value)
```

The model folder contains generated files such as `.apm`, `.csv`, `.dbs`, `results.json`, `options.json`, solver logs, and, when present, infeasibility diagnostics.

## 12. Repository assistant standards

When producing content for the GEKKO repository:

- Keep examples minimal, deterministic, and local where possible.
- Avoid network-only tests.
- Do not include credentials or hard-coded private servers.
- Include imports in every standalone example.
- Prefer concise, didactic comments.
- Include solver/mode settings close to model definitions.
- Provide a small diagnostic path for failures.


## APMonitor tutorial coverage

For tutorial-style user questions, also consult `docs/tutorial.md`. The skill includes one compact template for each of the 18 APMonitor GEKKO Python tutorial applications under `examples/apmonitor_18/`.

