# GEKKO Debugging Playbook

Use this playbook when a GEKKO model fails, returns unexpected values, is infeasible, is slow, or behaves differently between local and remote execution.

## 1. Start with a reproducible local model

Use:

```python
from gekko import GEKKO
m = GEKKO(remote=False)
```

Run with:

```python
m.options.DIAGLEVEL = 1
m.solve(disp=True, debug=1)
print("model folder:", m.path)
```

Open the folder manually or with:

```python
m.open_folder()
```

If a remote solve fails with "No solution or server unreachable", retry locally with `remote=False` to separate model issues from server/network issues.

## 2. Read the status

After solve:

```python
print("APPSTATUS:", m.options.APPSTATUS)
print("APPINFO:", m.options.APPINFO)
print("SOLVESTATUS:", m.options.SOLVESTATUS)
print("ITERATIONS:", m.options.ITERATIONS)
print("OBJFCNVAL:", m.options.OBJFCNVAL)
```

Interpretation:

- `APPSTATUS=1` normally indicates application success.
- `APPSTATUS=0` indicates failure.
- `APPINFO` gives solver-specific error detail.
- `OBJFCNVAL` is in minimized-objective form even when `m.Maximize()` is used.

## 3. Inspect generated files

In `m.path`, check:

- `*.apm` — model equations and declarations
- `*.csv` — data / time-varying values
- `measurements.dbs` — options and measurements
- `options.json` — options used by the solver
- `results.json` / `results.csv` — loaded results
- `APOPT.out`, `ipopt.out`, or solver output files
- `infeasibilities.txt` — infeasible equations and bounds when generated

For a non-converged model, include the key lines from the solver output and infeasibility file in any support request.

## 4. Infeasibility workflow

1. Solve the smallest model that reproduces the failure.
2. Temporarily remove the objective and solve as a feasibility problem.
3. Temporarily relax tight bounds.
4. Check units and signs.
5. Check initial guesses.
6. Check equations at the initial point manually.
7. Set `m.options.COLDSTART = 2` and solve again.
8. Inspect `infeasibilities.txt`.
9. Add constraints back one at a time.
10. If dynamic, reduce the horizon and number of time points.

Useful snippet:

```python
m.options.COLDSTART = 2
m.options.DIAGLEVEL = 1
try:
    m.solve(disp=True, debug=1)
except Exception:
    print("Inspect folder:", m.path)
    raise
```

`COLDSTART=2` can help identify infeasible equation/bound blocks by turning off degrees of freedom and analyzing model sparsity.

## 5. Degrees of freedom issues

Symptoms:

- "Degrees of Freedom" errors
- Square solve fails after adding variables/equations
- Control/estimation problem behaves as if an input is fixed

Checks:

- Every `Var` adds a degree of freedom unless constrained.
- `Param` and `Const` do not add DOF.
- `FV`/`MV` are decision variables only when `STATUS=1`.
- `CV` objectives are active only when `STATUS=1` in control modes.
- Measurements influence model only when `FSTATUS=1`.
- In estimation, `CV.STATUS` is not the fitting switch; use `CV.FSTATUS`.
- In control, use `MV.STATUS=1` for adjustable manipulated variables.

## 6. Scaling and numerical conditioning

GEKKO handles many scales, but badly scaled models are harder to solve.

Recommendations:

- Keep variables and residuals roughly in ranges such as `1e-3` to `1e3` when practical.
- Scale objective terms so one term does not dominate accidentally.
- Avoid huge penalties such as `1e12` unless necessary.
- Bound variables to physically meaningful ranges.
- Use good initial guesses for nonlinear equations.
- Replace divide-by-small expressions with protected formulations.
- Replace hard discontinuities with `if2`, `abs2`, `max2`, `min2`, splines, or binary forms if exact logic is required.

## 7. Dynamic model debugging

Checklist:

- `m.time` is set before solve.
- `len(m.time)` matches time-varying data vector lengths.
- `IMODE` is 4-9 when using `dt()`.
- Initial conditions are realistic.
- Time units match derivative units.
- Input vectors are `Param` or fixed `MV` values with correct length.
- Try fewer time points or lower `NODES` to isolate issues.
- For unstable systems, test open-loop simulation (`IMODE=4`) before control (`IMODE=6`).

## 8. Estimation debugging

Checklist:

- Measurements are assigned to `CV(value=data)` or `CV.MEAS`.
- `CV.FSTATUS=1` is set for measured outputs.
- Fitted scalar parameters are `FV` with `STATUS=1`.
- Use `IMODE=2` for steady-state regression and `IMODE=5` or `8` for dynamic estimation.
- Check that data arrays have compatible lengths.
- Start with one fitted parameter, then add more.

## 9. MPC/control debugging

Checklist:

- `MV.STATUS=1` for manipulated variables.
- `CV.STATUS=1` for controlled variables.
- `CV.FSTATUS=1` when using measurements to update the current state.
- `CV_TYPE=1` uses `SPHI`/`SPLO`; `CV_TYPE=2` uses `SP`.
- `TAU`, `TR_INIT`, `DMAX`, and `DCOST` are tuned to realistic move rates.
- Check `MV.NEWVAL`, `MV.PRED`, and `CV.PRED` after solve.
- Simulate the model first with a fixed MV.

## 10. Mixed-integer debugging

Checklist:

- Use `m.options.SOLVER=1`.
- Use tight bounds for integer variables.
- Avoid unnecessary integer variables.
- Provide feasible initial guesses.
- Adjust APOPT MINLP options only after model formulation is correct:

```python
m.solver_options = [
    'minlp_maximum_iterations 500',
    'minlp_max_iter_with_int_sol 10',
    'minlp_gap_tol 0.01',
]
```

## 11. Non-smooth expression debugging

Problematic with GEKKO variables:

```python
if x > 0: ...
max(x, 0)
abs(x)
numpy.exp(x)
```

Use GEKKO forms:

```python
y = m.if2(x, negative_expr, positive_expr)
z = m.max2(x, 0)
a = m.abs2(x)
e = m.exp(x)
```

For exact binary logic, use `if3`, `max3`, `abs3`, or explicit binary variables with `SOLVER=1`.

## 12. Support request checklist

When asking for help, include:

- Minimal runnable code
- GEKKO version and Python version
- Local or remote solve
- `IMODE`, `SOLVER`, and critical options
- Full solver error message
- Key solver log lines
- Any `infeasibilities.txt` content
- Expected behavior and actual behavior
