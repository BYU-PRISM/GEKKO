# GEKKO Modeling Patterns

This file contains compact patterns an assistant can adapt when answering GEKKO questions.

## 1. Algebraic equation solve

```python
from gekko import GEKKO

m = GEKKO(remote=False)

x = m.Var(value=1)
y = m.Var(value=1)

m.Equations([
    x + 2*y == 0,
    x**2 + y**2 == 1,
])

m.options.IMODE = 1
m.solve(disp=False)

print(x.value[0], y.value[0])
```

## 2. Steady-state nonlinear optimization

```python
from gekko import GEKKO

m = GEKKO(remote=False)
m.options.IMODE = 3
m.options.SOLVER = 3

x1 = m.Var(value=1, lb=1, ub=5)
x2 = m.Var(value=5, lb=1, ub=5)
x3 = m.Var(value=5, lb=1, ub=5)
x4 = m.Var(value=1, lb=1, ub=5)

m.Equation(x1*x2*x3*x4 >= 25)
m.Equation(x1**2 + x2**2 + x3**2 + x4**2 == 40)
m.Minimize(x1*x4*(x1 + x2 + x3) + x3)

m.solve(disp=False)
print([v.value[0] for v in [x1, x2, x3, x4]])
print("objective:", m.options.OBJFCNVAL)
```

## 3. Mixed-integer optimization

```python
from gekko import GEKKO

m = GEKKO(remote=False)
m.options.IMODE = 3
m.options.SOLVER = 1

x = m.Var(value=1, lb=0, ub=10)
n = m.Var(value=2, lb=0, ub=10, integer=True)

m.Equation(x + n >= 5)
m.Minimize((x - 3.2)**2 + (n - 4)**2)

m.solve(disp=False)
print(x.value[0], n.value[0])
```

## 4. Dynamic simulation

```python
from gekko import GEKKO
import numpy as np

m = GEKKO(remote=False)
m.time = np.linspace(0, 20, 101)

k = m.Param(value=0.4)
y = m.Var(value=5.0)

m.Equation(y.dt() == -k * y)

m.options.IMODE = 4
m.options.NODES = 3
m.solve(disp=False)

print(y.value[-1])
```

## 5. Steady-state parameter estimation

```python
from gekko import GEKKO
import numpy as np

x_data = np.array([0, 1, 2, 3, 4, 5], dtype=float)
y_data = np.array([0.1, 0.2, 0.3, 0.5, 0.8, 2.0], dtype=float)

m = GEKKO(remote=False)
m.options.IMODE = 2
m.options.SOLVER = 3

x = m.Param(value=x_data)

a = m.FV(value=0.5, lb=0, ub=5)
a.STATUS = 1

y = m.CV(value=y_data)
y.FSTATUS = 1

m.Equation(y == 0.1 * m.exp(a * x))

m.solve(disp=False)
print("a:", a.value[0])
print("fit:", y.value)
```

## 6. Dynamic optimization with terminal target

```python
from gekko import GEKKO
import numpy as np

m = GEKKO(remote=False)
m.time = np.linspace(0, 10, 51)

x = m.Var(value=0)
u = m.MV(value=0, lb=-1, ub=1)
u.STATUS = 1
u.DCOST = 1e-3

final = np.zeros(len(m.time))
final[-1] = 1
final = m.Param(value=final)

m.Equation(x.dt() == u)
m.Minimize(u**2)
m.Minimize(1000 * final * (x - 5)**2)

m.options.IMODE = 6
m.options.SOLVER = 3
m.solve(disp=False)

print("terminal x:", x.value[-1])
```

## 7. MPC first-order control

```python
from gekko import GEKKO
import numpy as np

m = GEKKO(remote=False)
m.time = np.linspace(0, 20, 41)

u = m.MV(value=0, lb=0, ub=100)
u.STATUS = 1
u.DCOST = 0.1
u.DMAX = 10

y = m.CV(value=0)
y.STATUS = 1
y.FSTATUS = 1
y.SP = 40
y.TAU = 5
y.TR_INIT = 2

m.Equation(5 * y.dt() == -y + u)

m.options.IMODE = 6
m.options.CV_TYPE = 2
m.options.SOLVER = 3

m.solve(disp=False)

print("new move:", u.NEWVAL)
print("predicted y:", y.PRED)
```

## 8. Piecewise or conditional expression

Smooth complementarity switch:

```python
y = m.if2(x - 5, low_expr, high_expr)
```

Binary switch:

```python
m.options.SOLVER = 1
y = m.if3(x - 5, low_expr, high_expr)
```

Absolute value:

```python
smooth_abs = m.abs2(x)
binary_abs = m.abs3(x)
```

## 9. Read and report diagnostics

```python
from pathlib import Path

def print_gekko_diagnostics(m):
    folder = Path(m.path)
    print("GEKKO folder:", folder)

    for name in ["infeasibilities.txt", "APOPT.out", "ipopt.out", "results.json", "options.json"]:
        path = folder / name
        if path.exists():
            print(f"\n--- {name} ---")
            text = path.read_text(errors="replace")
            print(text[:4000])
```

Use this after a failed solve or after a verbose local solve.

## 10. Import data from Python

```python
import pandas as pd
from gekko import GEKKO

df = pd.read_csv("data.csv")

m = GEKKO(remote=False)
m.time = df["time"].to_numpy()

u = m.Param(value=df["u"].to_numpy())
y = m.CV(value=df["y"].to_numpy())
y.FSTATUS = 1
```

Keep data parsing in Python and pass numeric arrays into GEKKO parameters or variables.


## APMonitor 18 templates

Use these files for full tutorial-style examples:

```text
examples/apmonitor_18/
  01_solver_selection.py
  02_linear_equations.py
  03_nonlinear_equations.py
  04_cubic_spline.py
  05_polynomial_regression.py
  06_nonlinear_regression.py
  07_neural_network_brain.py
  08_differential_equation.py
  09_nlp_optimization.py
  10_minlp_integer.py
  11_ocp_integral_objective.py
  12_ocp_economic_objective.py
  13_ocp_minimize_final_time.py
  14_pid_simulation.py
  15_process_simulator.py
  16_mhe_estimation.py
  17_mpc_control.py
  18_debugging_resources.py
```

When adapting these examples for users, preserve the GEKKO structure but simplify the code to the user's actual equations and data.
