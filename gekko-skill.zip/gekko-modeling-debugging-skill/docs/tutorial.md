# APMonitor GEKKO Python Tutorial Coverage

Use this document when a user asks a GEKKO question similar to any APMonitor tutorial example. The goal is to route quickly to the correct GEKKO formulation, not to force every answer into a tutorial script.

## Tutorial problem classes

| # | Problem class | GEKKO formulation | Example file |
|---:|---|---|---|
| 1 | Solver selection | `m.options.SOLVER = 1` for APOPT, `2` for BPOPT, `3` for IPOPT | `examples/apmonitor_18/01_solver_selection.py` |
| 2 | Linear equations | Algebraic variables and `m.Equations([...])` | `examples/apmonitor_18/02_linear_equations.py` |
| 3 | Nonlinear equations | Initial guesses plus nonlinear `m.Equations([...])` | `examples/apmonitor_18/03_nonlinear_equations.py` |
| 4 | Cubic spline | `m.cspline(x, y, x_data, y_data)`; use `IMODE=2` for interpolation | `examples/apmonitor_18/04_cubic_spline.py` |
| 5 | Polynomial regression | `FV` coefficients, `CV` measurements, `IMODE=2` | `examples/apmonitor_18/05_polynomial_regression.py` |
| 6 | Nonlinear regression | Adjustable `FV` parameters with nonlinear equations | `examples/apmonitor_18/06_nonlinear_regression.py` |
| 7 | Machine learning | `gekko.brain` or explicit network with `FV` weights | `examples/apmonitor_18/07_neural_network_brain.py` |
| 8 | Differential equation | `m.time`, `.dt()`, dynamic `IMODE=4` | `examples/apmonitor_18/08_differential_equation.py` |
| 9 | NLP optimization | `IMODE=3`, continuous variables, bounds, objective | `examples/apmonitor_18/09_nlp_optimization.py` |
| 10 | MINLP | `integer=True`, APOPT solver, MINLP options | `examples/apmonitor_18/10_minlp_integer.py` |
| 11 | Integral objective optimal control | Add state variable that integrates the objective, or weight terminal point | `examples/apmonitor_18/11_ocp_integral_objective.py` |
| 12 | Economic optimal control | Dynamic profit/cost balance, terminal objective, `MV.STATUS=1` | `examples/apmonitor_18/12_ocp_economic_objective.py` |
| 13 | Minimum final time | Introduce `tf` as an `FV` and scale differential equations by `tf` | `examples/apmonitor_18/13_ocp_minimize_final_time.py` |
| 14 | PID simulation | Dynamic controller and process equations, `IMODE=4` | `examples/apmonitor_18/14_pid_simulation.py` |
| 15 | Process simulation | Generate dynamic response data from inputs and process model | `examples/apmonitor_18/15_process_simulator.py` |
| 16 | Moving horizon estimation | `IMODE=5` or `8`; adjust `FV`s; use `CV` measurements | `examples/apmonitor_18/16_mhe_estimation.py` |
| 17 | Model predictive control | `IMODE=6` or `9`; `MV` moves; `CV` set point tracking | `examples/apmonitor_18/17_mpc_control.py` |
| 18 | Debugging resources | `m.path`, `m.open_folder()`, `debug=1`, `DIAGLEVEL`, generated files | `examples/apmonitor_18/18_debugging_resources.py` |

## How to choose a mode

- `IMODE=1`: steady-state simulation / equation solve.
- `IMODE=2`: steady-state parameter estimation or data fitting across data rows.
- `IMODE=3`: steady-state optimization.
- `IMODE=4`: dynamic simulation over `m.time`.
- `IMODE=5`: moving horizon estimation.
- `IMODE=6`: dynamic optimization / MPC / optimal control.
- `IMODE=7`, `8`, `9`: sequential versions of dynamic simulation, estimation, and control.

## Variable class reminders

- `Const`: fixed scalar constant.
- `Param`: fixed scalar or time/data-vector input.
- `Var`: algebraic or differential variable.
- `SV`: state variable with feedback features for dynamic estimation/control.
- `CV`: controlled/measured variable with objective features.
- `FV`: fixed value across horizon that optimizer may estimate when `STATUS=1`.
- `MV`: manipulated variable that may move across a dynamic horizon when `STATUS=1`.

## Answer patterns by problem type

### Equation solving

Use `m.Var` for unknowns, `m.Param` for known constants, and `m.Equation` / `m.Equations` for algebraic relationships. For nonlinear equations, set credible initial guesses and bounds.

### Regression / estimation

Use `m.options.IMODE=2` for data-row fitting. Put measured data on a `CV` with `FSTATUS=1`, and turn on adjustable coefficients with `FV.STATUS=1`.

### Dynamic simulation

Set `m.time`, write differential equations with `.dt()`, set `IMODE=4`, and use `Param(value=array)` for time-varying inputs.

### Optimization

For continuous steady-state problems, set `IMODE=3` and use IPOPT (`SOLVER=3`) or APOPT (`SOLVER=1`). For mixed-integer problems, use APOPT and declare integer variables with `integer=True`.

### Optimal control / MPC

Use `m.time`, `MV.STATUS=1`, and `IMODE=6`. For set point tracking, use `CV` options such as `SP`, `SPLO`, `SPHI`, `TAU`, `TR_INIT`, and `CV_TYPE`. For economic objectives, write explicit objective expressions with `m.Minimize`, `m.Maximize`, or `m.Obj`.

### MHE

Use `IMODE=5` or `8`. Measurements should enter through `CV.value` / `CV.MEAS` with `FSTATUS=1`. Estimated parameters are typically `FV` objects with `STATUS=1`, bounds, and optional `DMAX`.

### Debugging

Use `GEKKO(remote=False)` for reproducibility, `m.solve(disp=True, debug=1)` for verbose output, and inspect `m.path` for model files. If infeasible, check `infeasibilities.txt`, relax constraints, verify units/scaling, and inspect initial guesses and bounds.

## Common corrections

- Replace Python conditionals on GEKKO variables with `if2`, `if3`, logical equations, or binary variables.
- Replace `numpy.exp`, `numpy.sin`, and similar functions on GEKKO variables with `m.exp`, `m.sin`, etc.
- Do not use `len(variable)` or iterate over a scalar GEKKO variable as though it were a NumPy array.
- For final-time objectives, introduce a final-point `Param` vector or use `m.fix_final` / `m.Connection` when appropriate.
- For dynamic optimization with a free final time, scale differential equations by `tf` and optimize `tf` as an `FV`.
- For nonconvex NLP/MINLP, try multiple initial guesses and consider whether the returned point is local.
