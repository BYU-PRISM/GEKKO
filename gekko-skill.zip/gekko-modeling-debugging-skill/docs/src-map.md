# GEKKO Documentation Source Map

Use official sources first.

## Official documentation

- GEKKO latest docs: https://gekko.readthedocs.io/en/latest/
- Quick Start Model Building: https://gekko.readthedocs.io/en/latest/quick_start.html
- Modes / IMODE: https://gekko.readthedocs.io/en/latest/imode.html
- Global Options: https://gekko.readthedocs.io/en/latest/global.html
- Tuning Parameters: https://gekko.readthedocs.io/en/latest/tuning_params.html
- MV Options: https://gekko.readthedocs.io/en/latest/MV_options.html
- CV Options: https://gekko.readthedocs.io/en/latest/CV_options.html
- Model Building / Methods: https://gekko.readthedocs.io/en/latest/model_methods.html
- Deep Learning / `brain`: https://gekko.readthedocs.io/en/latest/brain.html
- Machine Learning imports: https://gekko.readthedocs.io/en/latest/ml.html
- Chemical Library: https://gekko.readthedocs.io/en/latest/chemical.html
- Solver Extension: https://gekko.readthedocs.io/en/latest/solver_extension.html
- Examples: https://gekko.readthedocs.io/en/latest/examples.html

## APMonitor tutorial coverage

- GEKKO Python Tutorials: https://apmonitor.com/wiki/index.php/Main/GekkoPythonOptimization
- APMonitor error messages: https://apmonitor.com/wiki/index.php/Main/ErrorMessages
- APMonitor global options: https://apmonitor.com/wiki/index.php/Main/OptionApmSolver
- APMonitor application modes: https://apmonitor.com/wiki/index.php/Main/Modes

## Repository and archive

- GEKKO GitHub: https://github.com/BYU-PRISM/GEKKO
- GEKKO source archive: https://github.com/BYU-PRISM/GEKKO/archive/refs/heads/master.zip

## Local generated model files

When a model is solved, GEKKO writes files to `m.path`. Useful files may include:

- `.apm` model file
- `.csv` data file
- `.dbs` options file
- `results.json`
- `options.json`
- `APOPT.out`
- `ipopt.out`
- `infeasibilities.txt`

Use these files to diagnose malformed equations, infeasible constraints, solver status, and unexpected option settings.
