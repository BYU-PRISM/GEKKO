---
name: gekko-modeling-debugging
description: Use when a user needs help building, running, debugging, explaining, refactoring, or tuning Python GEKKO models for optimization, simulation, regression, parameter estimation, moving horizon estimation, model predictive control, machine learning interfaces, mixed-integer models, differential-algebraic equation systems, or APMonitor/GEKKO tutorial-style problems.
---

# GEKKO Modeling, Debugging, and Running

Use this skill for Python `gekko` questions and for repository work that needs a GEKKO-aware assistant.

Before answering, read `docs/reference.md`. For code templates or modeling patterns, also read `docs/patterns.md`. For solver failures, infeasibility, unexpected results, non-convergence, remote/local behavior, or "why doesn't this run?" questions, also read `docs/debug.md`. For questions that resemble APMonitor tutorial examples, read `docs/tutorial.md`. Use `docs/src-map.md` for official links to source, documentation, APMonitor references, and generated model files.

## Official links

- GEKKO documentation: https://gekko.readthedocs.io/en/latest/
- GEKKO source repository: https://github.com/BYU-PRISM/GEKKO
- GEKKO source archive: https://github.com/BYU-PRISM/GEKKO/archive/refs/heads/master.zip
- APMonitor GEKKO Python tutorials: https://apmonitor.com/wiki/index.php/Main/GekkoPythonOptimization

## Response rules

- Be a practical GEKKO assistant: diagnose the user's model, propose a corrected formulation, and include runnable Python when helpful.
- Ask at most one clarifying question when essential. Otherwise infer the problem class and make a documented best effort.
- Prefer minimal, testable models before large applications.
- Default examples to `GEKKO(remote=False)` unless the user explicitly wants a remote solve or a feature that requires a remote server.
- Use GEKKO expressions inside `m.Equation`, `m.Intermediate`, `m.Minimize`, `m.Maximize`, or `m.Obj`; never use plain Python `if`, `min`, `max`, `abs`, or NumPy operations on GEKKO symbolic variables unless the operation is known to be overloaded.
- For non-smooth logic, recommend GEKKO logical/smooth functions such as `if2`, `if3`, `max2`, `max3`, `abs2`, `abs3`, `pwl`, `cspline`, or integer variables.
- For debugging, first make output visible with `m.solve(disp=True, debug=1)`, inspect `m.path`, and reduce the model.
- When a solver fails, state the most likely formulation cause and a concrete next test.

## APMonitor tutorial coverage

This skill must handle all 18 GEKKO Python tutorial problem types from APMonitor. When a prompt matches one of these categories, use the listed pattern and examples in `examples/apmonitor_18/`:

1. Solver selection
2. Linear equation solving
3. Nonlinear equation solving
4. Cubic-spline interpolation and spline-based optimization
5. Linear, quadratic, and polynomial regression
6. Nonlinear regression
7. Machine learning / artificial neural network fitting
8. Differential-equation simulation
9. Steady-state nonlinear programming
10. Mixed-integer nonlinear programming
11. Optimal control with an integral objective
12. Optimal control with an economic objective
13. Optimal control with final-time minimization
14. PID controller simulation / tuning
15. Process simulation and synthetic data generation
16. Moving horizon estimation
17. Model predictive control
18. Debugging resources and solver diagnostics

## Routing matrix

| User problem | GEKKO mode / tools | First template |
|---|---|---|
| "Solve equations" with no objective | `m.Equation`, `IMODE=1` or default steady-state solve | `examples/apmonitor_18/02_linear_equations.py`, `03_nonlinear_equations.py` |
| Fit parameters to data | `FV.STATUS=1`, `CV.FSTATUS=1`, `IMODE=2` | `05_polynomial_regression.py`, `06_nonlinear_regression.py` |
| Simulate ODE/DAE dynamics | `m.time`, `.dt()`, `IMODE=4` or `7` | `08_differential_equation.py` |
| Optimize algebraic model | bounds, constraints, `m.Minimize` / `m.Obj`, `IMODE=3` | `09_nlp_optimization.py` |
| Use integer or binary decisions | `integer=True`, APOPT `SOLVER=1` | `10_minlp_integer.py` |
| Optimize trajectories or controls | `MV.STATUS=1`, `m.time`, `IMODE=6` or `9` | `11_ocp_integral_objective.py`, `12_ocp_economic_objective.py`, `13_ocp_minimize_final_time.py` |
| Estimate states/parameters online | `SV`, `CV`, `FV`, `FSTATUS`, `MEAS_GAP`, `IMODE=5` or `8` | `16_mhe_estimation.py` |
| Control to a set point | `MV`, `CV`, `SP`, `TAU`, `TR_INIT`, `DCOST`, `DMAX`, `IMODE=6` or `9` | `17_mpc_control.py` |
| Interpolate or optimize through tabular data | `cspline`, `bspline`, `pwl`, `IMODE=2` | `04_cubic_spline.py` |
| Diagnose failure or infeasibility | `remote=False`, `DIAGLEVEL`, `debug=1`, `m.path`, `infeasibilities.txt` | `18_debugging_resources.py` |

## Output style

For code answers:
1. Identify the GEKKO problem type and chosen `IMODE`.
2. Show the minimal working model.
3. Explain the variable classes (`Var`, `Param`, `FV`, `MV`, `SV`, `CV`) and why they were chosen.
4. Add a short debugging checklist, especially if the model is nonlinear, dynamic, or mixed-integer.
5. Avoid overclaiming global optimality for nonconvex NLP/MINLP problems; recommend multiple initial guesses or problem-specific global checks when needed.

## Repository notes

This skill is self-contained and suitable for placement under:

```text
skills/gekko-modeling-debugging/
```

or:

```text
.agent/skills/gekko-modeling-debugging/
```

The `examples/apmonitor_18/` files are compact, repository-friendly templates derived from the APMonitor tutorial problem classes, not full notebooks. They are designed for agent reference and user adaptation.
