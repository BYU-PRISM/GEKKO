"""Dynamic simulation with a first-order decay model."""

import numpy as np
from gekko import GEKKO


def main():
    m = GEKKO(remote=False)
    m.time = np.linspace(0, 20, 101)

    k = m.Param(value=0.4)
    y = m.Var(value=5.0)

    m.Equation(y.dt() == -k * y)

    m.options.IMODE = 4
    m.options.NODES = 3

    m.solve(disp=False)

    print("final y:", y.value[-1])


if __name__ == "__main__":
    main()
