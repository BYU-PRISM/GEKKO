"""APMonitor tutorial 09: nonlinear programming optimization."""

from gekko import GEKKO


def build_model(remote=False):
    m = GEKKO(remote=remote)
    m.options.IMODE = 3
    m.options.SOLVER = 3

    x1 = m.Var(value=1, lb=1, ub=5)
    x2 = m.Var(value=5, lb=1, ub=5)
    x3 = m.Var(value=5, lb=1, ub=5)
    x4 = m.Var(value=1, lb=1, ub=5)

    m.Equation(x1 * x2 * x3 * x4 >= 25)
    m.Equation(x1**2 + x2**2 + x3**2 + x4**2 == 40)
    m.Minimize(x1 * x4 * (x1 + x2 + x3) + x3)
    return m, (x1, x2, x3, x4)


def main():
    m, x = build_model()
    m.solve(disp=False)
    print("x:", [xi.value[0] for xi in x])
    print("objective:", m.options.OBJFCNVAL)


if __name__ == "__main__":
    main()
