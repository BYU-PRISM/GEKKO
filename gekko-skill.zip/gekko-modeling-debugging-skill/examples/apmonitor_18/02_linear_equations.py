"""APMonitor tutorial 02: solve a system of linear equations."""

from gekko import GEKKO


def build_model(remote=False):
    m = GEKKO(remote=remote)
    x = m.Var()
    y = m.Var()
    m.Equations([
        3 * x + 2 * y == 1,
        x + 2 * y == 0,
    ])
    return m, x, y


def main():
    m, x, y = build_model()
    m.solve(disp=False)
    print("x:", x.value[0])
    print("y:", y.value[0])


if __name__ == "__main__":
    main()
