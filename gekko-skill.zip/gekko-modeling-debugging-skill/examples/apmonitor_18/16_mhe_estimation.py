"""APMonitor tutorial 16: moving horizon estimation.

The example first generates synthetic data, then estimates model parameters
from the measured input/output data.
"""

import numpy as np
from gekko import GEKKO


def make_data(seed=1):
    rng = np.random.default_rng(seed)
    nt = 51
    time = np.linspace(0, 10, nt)

    u_meas = np.zeros(nt)
    u_meas[3:10] = 1.0
    u_meas[10:20] = 2.0
    u_meas[20:40] = 0.5
    u_meas[40:] = 3.0

    # Use an analytical first-order response approximation for compactness.
    y = np.zeros(nt)
    dt = time[1] - time[0]
    true_gain = 1.0
    true_tau = 5.0
    for k in range(1, nt):
        y[k] = y[k - 1] + dt * (-y[k - 1] + true_gain * u_meas[k - 1]) / true_tau

    y_meas = y + (rng.random(nt) - 0.5) * 0.2
    return time, u_meas, y_meas


def build_estimator(remote=False):
    time, u_meas, y_meas = make_data()

    m = GEKKO(remote=remote)
    m.time = time

    u = m.MV(value=u_meas)
    gain = m.FV(value=1.0, lb=0.2, ub=3.0)
    tau = m.FV(value=5.0, lb=0.5, ub=10.0)
    x = m.SV()
    y = m.CV(value=y_meas)

    m.Equations([
        tau * x.dt() == -x + u,
        y == gain * x,
    ])

    m.options.IMODE = 5
    m.options.EV_TYPE = 1

    u.STATUS = 0
    u.FSTATUS = 1

    gain.STATUS = 1
    gain.FSTATUS = 0
    gain.DMAX = 2.0

    tau.STATUS = 1
    tau.FSTATUS = 0
    tau.DMAX = 4.0

    y.STATUS = 1
    y.FSTATUS = 1
    y.MEAS_GAP = 0.25

    return m, gain, tau, y, y_meas


def main():
    m, gain, tau, y, y_meas = build_estimator()
    m.solve(disp=False)
    print("estimated gain:", gain.value[0])
    print("estimated tau:", tau.value[0])


if __name__ == "__main__":
    main()
