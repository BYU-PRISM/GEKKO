"""APMonitor tutorial 12: optimal control with economic objective."""

import numpy as np
from gekko import GEKKO


def build_model(remote=False):
    m = GEKKO(remote=remote)
    m.time = np.linspace(0, 10, 501)

    effort_price = 1.0
    cost = 17.5
    growth = 0.71
    carrying_capacity = 80.5
    max_harvest = 20.0

    u = m.MV(value=1.0, lb=0, ub=1)
    u.STATUS = 1
    u.DCOST = 0

    population = m.Var(value=70.0)
    profit = m.Var(value=0.0)
    final_profit = m.FV()
    final_profit.STATUS = 1

    m.Connection(final_profit, profit, pos2="end")
    m.Equation(population.dt() == growth * population * (1 - population / carrying_capacity) - u * max_harvest)
    m.Equation(profit.dt() == (effort_price - cost / population) * u * max_harvest)
    m.Maximize(final_profit)

    m.options.IMODE = 6
    m.options.NODES = 3
    m.options.SOLVER = 3
    return m, population, u, profit, final_profit


def main():
    m, population, u, profit, final_profit = build_model()
    m.solve(disp=False)
    print("optimal profit:", final_profit.value[0])
    print("terminal population:", population.value[-1])


if __name__ == "__main__":
    main()
