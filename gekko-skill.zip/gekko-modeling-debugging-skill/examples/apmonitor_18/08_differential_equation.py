"""APMonitor tutorial 08: dynamic simulation of a differential equation."""

import numpy as np
from gekko import GEKKO


def build_model(remote=False):
    m = GEKKO(remote=remote)
    m.time = np.linspace(0, 20, 100)

    k = m.Param(value=10.0)
    t = m.Param(value=m.time)
    y = m.Var(value=5.0)

    m.Equation(k * y.dt() == -t * y)
    m.options.IMODE = 4
    return m, y


def main():
    m, y = build_model()
    m.solve(disp=False)
    print("final y:", y.value[-1])


if __name__ == "__main__":
    main()
