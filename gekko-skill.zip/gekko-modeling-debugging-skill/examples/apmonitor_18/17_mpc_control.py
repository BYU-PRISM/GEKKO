"""APMonitor tutorial 17: model predictive control."""

import json
import os
import numpy as np
from gekko import GEKKO


def build_controller(remote=False):
    m = GEKKO(remote=remote)
    m.time = np.linspace(0, 20, 41)

    mass = 500.0
    drag = m.Param(value=50.0)
    gain = m.Param(value=0.8)

    pedal = m.MV(value=0.0, lb=0, ub=100)
    pedal.STATUS = 1
    pedal.DCOST = 0.1
    pedal.DMAX = 20

    velocity = m.CV(value=0.0)
    velocity.STATUS = 1
    velocity.SP = 40
    velocity.TR_INIT = 1
    velocity.TAU = 5

    m.Equation(mass * velocity.dt() == -velocity * drag + gain * drag * pedal)

    m.options.IMODE = 6
    m.options.CV_TYPE = 2
    return m, pedal, velocity


def load_reference_trajectory(m, variable_name="v1"):
    """Read a reference trajectory from results.json when available."""
    path = os.path.join(m.path, "results.json")
    if not os.path.exists(path):
        return None
    with open(path, encoding="utf-8") as f:
        results = json.load(f)
    return results.get(f"{variable_name}.tr")


def main():
    m, pedal, velocity = build_controller()
    m.solve(disp=False)
    print("first optimized move:", pedal.NEWVAL)
    print("predicted terminal velocity:", velocity.value[-1])


if __name__ == "__main__":
    main()
