"""APMonitor tutorial 15: process simulator and synthetic data generation."""

import numpy as np
from gekko import GEKKO


def simulate_process(remote=False, seed=1):
    rng = np.random.default_rng(seed)
    nt = 51

    u_meas = np.zeros(nt)
    u_meas[3:10] = 1.0
    u_meas[10:20] = 2.0
    u_meas[20:40] = 0.5
    u_meas[40:] = 3.0

    m = GEKKO(remote=remote)
    m.time = np.linspace(0, 10, nt)

    n = 1
    u = m.MV(value=u_meas)
    u.FSTATUS = 1
    gain = m.Param(value=1.0)
    tau = m.Param(value=5.0)

    states = [m.Intermediate(u)]
    states.extend(m.Var() for _ in range(n))
    y = m.SV()

    m.Equations([
        tau / n * states[i + 1].dt() == -states[i + 1] + states[i]
        for i in range(n)
    ])
    m.Equation(y == gain * states[n])

    m.options.IMODE = 4
    m.solve(disp=False)

    y_clean = np.array(y.value, dtype=float)
    y_noisy = y_clean + (rng.random(nt) - 0.5) * 0.2
    return np.array(m.time), u_meas, y_clean, y_noisy


def main():
    time, u, y_clean, y_noisy = simulate_process()
    print("samples:", len(time))
    print("final clean/noisy:", y_clean[-1], y_noisy[-1])


if __name__ == "__main__":
    main()
