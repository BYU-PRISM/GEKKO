"""APMonitor tutorial 06: nonlinear regression with adjustable parameters."""

import numpy as np
from gekko import GEKKO


def build_model(remote=False):
    x_data = np.array([0, 1, 2, 3, 4, 5], dtype=float)
    y_data = np.array([0.1, 0.2, 0.3, 0.5, 0.8, 2.0], dtype=float)

    m = GEKKO(remote=remote)
    m.options.IMODE = 2
    m.options.EV_TYPE = 2

    x = m.Param(value=x_data)
    a = m.FV(value=0.5, lb=-10, ub=10)
    a.STATUS = 1

    y = m.CV(value=y_data)
    y.FSTATUS = 1

    m.Equation(y == 0.1 * m.exp(a * x))
    return m, a, y


def main():
    m, a, y = build_model()
    m.solve(disp=False)
    print("a:", a.value[0])
    print("fit:", y.value)


if __name__ == "__main__":
    main()
