"""APMonitor tutorial 18: debugging resources and solver diagnostics."""

from pathlib import Path
from gekko import GEKKO


def print_diagnostic_files(m, max_chars=3000):
    """Print useful GEKKO model-folder files if they exist."""
    folder = Path(m.path)
    print("GEKKO model folder:", folder)

    for name in [
        "infeasibilities.txt",
        "APOPT.out",
        "ipopt.out",
        "results.json",
        "options.json",
        "apm.log",
    ]:
        path = folder / name
        if path.exists():
            print(f"\n--- {name} ---")
            print(path.read_text(errors="replace")[:max_chars])


def build_debug_model(remote=False):
    m = GEKKO(remote=remote)
    u = m.FV(value=5, name="u")
    x = m.SV(name="state")

    m.Equation(x == u)

    m.options.COLDSTART = 1
    m.options.DIAGLEVEL = 1
    m.options.MAX_ITER = 500
    m.options.SENSITIVITY = 1
    m.options.SOLVER = 1
    return m, u, x


def solve_with_debug(m):
    try:
        m.solve(disp=True, debug=1)
    except Exception:
        print_diagnostic_files(m)
        raise


def main():
    m, u, x = build_debug_model()
    print("model folder:", m.path)
    solve_with_debug(m)
    print("x:", x.value)


if __name__ == "__main__":
    main()
