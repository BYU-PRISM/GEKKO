"""APMonitor tutorial 13: optimal control with final-time minimization.

The normalized horizon is [0, 1]. The physical final time is an adjustable FV
`tf`, and all differential equations are scaled by `tf`.
"""

import numpy as np
from gekko import GEKKO


def build_model(remote=False):
    m = GEKKO(remote=remote)
    nt = 501
    m.time = np.linspace(0, 1, nt)

    x1 = m.Var(value=np.pi / 2.0)
    x2 = m.Var(value=4.0)
    x3 = m.Var(value=0.0)

    final_mask = np.zeros(nt)
    final_mask[-1] = 1.0
    final = m.Param(value=final_mask)

    tf = m.FV(value=1.0, lb=0.1, ub=100.0)
    tf.STATUS = 1

    u = m.MV(value=0.0, lb=-2, ub=2)
    u.STATUS = 1

    m.Equation(x1.dt() == u * tf)
    m.Equation(x2.dt() == m.cos(x1) * tf)
    m.Equation(x3.dt() == m.sin(x1) * tf)

    m.Equation(x2 * final <= 0)
    m.Equation(x3 * final <= 0)
    m.Minimize(tf)

    m.options.IMODE = 6
    return m, x1, x2, x3, u, tf


def main():
    m, x1, x2, x3, u, tf = build_model()
    m.solve(disp=False)
    print("final time:", tf.value[0])
    print("terminal states:", x1.value[-1], x2.value[-1], x3.value[-1])


if __name__ == "__main__":
    main()
