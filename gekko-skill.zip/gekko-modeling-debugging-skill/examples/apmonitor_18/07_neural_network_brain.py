"""APMonitor tutorial 07: machine learning / artificial neural network.

This uses the optional GEKKO `brain` helper. It is intentionally small so it can
serve as a starting point for fitting, validating, and embedding a neural model.
"""

import numpy as np
from gekko import brain


def train_sine_brain():
    x = np.linspace(0.0, 2.0 * np.pi, 20)
    y = np.sin(x)

    b = brain.Brain()
    b.input_layer(1)
    b.layer(linear=2)
    b.layer(tanh=3)
    b.layer(linear=2)
    b.output_layer(1)

    b.learn(np.array(x), np.array(y))
    return b


def main():
    b = train_sine_brain()
    xp = np.linspace(-2.0 * np.pi, 4.0 * np.pi, 100)
    yp = b.think(xp)
    print("predictions:", yp[0][:5])


if __name__ == "__main__":
    main()
