"""APMonitor tutorial 04: cubic spline interpolation and optimization.

This demonstrates two related tasks:
1. Interpolate tabular data with `m.cspline`.
2. Optimize over the spline by choosing the independent variable.
"""

import numpy as np
from gekko import GEKKO


def interpolation_model(remote=False):
    x_data = np.array([0, 1, 2, 3, 4, 5], dtype=float)
    y_data = np.array([0.1, 0.2, 0.3, 0.5, 1.0, 0.9], dtype=float)

    m = GEKKO(remote=remote)
    m.options.IMODE = 2
    x = m.Param(value=np.linspace(-1, 6, 50))
    y = m.Var()
    m.cspline(x, y, x_data, y_data)
    return m, x, y


def optimization_model(remote=False):
    x_data = np.array([0, 1, 2, 3, 4, 5], dtype=float)
    y_data = np.array([0.1, 0.2, 0.3, 0.5, 1.0, 0.9], dtype=float)

    m = GEKKO(remote=remote)
    x = m.Var(value=1.0, lb=0, ub=5)
    y = m.Var()
    m.cspline(x, y, x_data, y_data)
    m.Maximize(y)
    return m, x, y


def main():
    m, x, y = interpolation_model()
    m.solve(disp=False)
    print("interpolated first/last:", y.value[0], y.value[-1])

    opt, xopt, yopt = optimization_model()
    opt.solve(disp=False)
    print("spline maximum near:", xopt.value[0], yopt.value[0])


if __name__ == "__main__":
    main()
