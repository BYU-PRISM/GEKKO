"""APMonitor tutorial 11: optimal control with integral objective."""

import numpy as np
from gekko import GEKKO


def build_model(remote=False):
    m = GEKKO(remote=remote)
    nt = 101
    m.time = np.linspace(0, 2, nt)

    x1 = m.Var(value=1.0)
    x2 = m.Var(value=0.0)
    u = m.MV(value=0.0, lb=-1, ub=1)
    u.STATUS = 1

    final_mask = np.zeros(nt)
    final_mask[-1] = 1.0
    final = m.Param(value=final_mask)

    m.Equation(x1.dt() == u)
    m.Equation(x2.dt() == 0.5 * x1**2)
    m.Minimize(x2 * final)

    m.options.IMODE = 6
    return m, x1, x2, u


def main():
    m, x1, x2, u = build_model()
    m.solve(disp=False)
    print("terminal objective:", x2.value[-1])
    print("first control move:", u.value[0])


if __name__ == "__main__":
    main()
