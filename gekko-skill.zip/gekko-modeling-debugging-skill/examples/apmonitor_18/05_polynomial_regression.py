"""APMonitor tutorial 05: linear, quadratic, and polynomial regression."""

import numpy as np
from gekko import GEKKO


def fit_polynomial(degree=3, remote=False):
    x_data = np.array([0, 1, 2, 3, 4, 5], dtype=float)
    y_data = np.array([0.1, 0.2, 0.3, 0.5, 0.8, 2.0], dtype=float)

    m = GEKKO(remote=remote)
    m.options.IMODE = 2

    x = m.Param(value=x_data)
    y = m.CV(value=y_data)
    y.FSTATUS = 1

    coeff = [m.FV(value=0.0) for _ in range(degree + 1)]
    for c in coeff:
        c.STATUS = 1

    prediction = sum(coeff[i] * x**i for i in range(degree + 1))
    m.Equation(y == prediction)
    return m, coeff, y


def main():
    for degree in (1, 2, 3):
        m, coeff, y = fit_polynomial(degree)
        m.solve(disp=False)
        print(f"degree {degree} coefficients:", [c.value[0] for c in coeff])


if __name__ == "__main__":
    main()
