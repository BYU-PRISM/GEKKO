"""APMonitor tutorial 03: solve nonlinear algebraic equations."""

from gekko import GEKKO


def build_model(remote=False):
    m = GEKKO(remote=remote)
    x = m.Var(value=0.0)
    y = m.Var(value=1.0)
    m.Equations([
        x + 2 * y == 0,
        x**2 + y**2 == 1,
    ])
    return m, x, y


def main():
    m, x, y = build_model()
    m.solve(disp=False)
    print("solution:", x.value[0], y.value[0])


if __name__ == "__main__":
    main()
