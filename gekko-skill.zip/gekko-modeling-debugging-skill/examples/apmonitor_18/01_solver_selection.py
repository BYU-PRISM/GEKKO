"""APMonitor tutorial 01: solver selection.

APOPT (`SOLVER=1`) is often used for MINLP and constrained nonlinear models.
BPOPT (`SOLVER=2`) and IPOPT (`SOLVER=3`) are continuous nonlinear solvers.
"""

from gekko import GEKKO


def build_model(solver=1, remote=False):
    m = GEKKO(remote=remote)
    y = m.Var(value=2.0)
    m.Equation(y**2 == 1)
    m.options.SOLVER = solver
    return m, y


def main():
    m, y = build_model(solver=1)
    m.solve(disp=False)
    print("y:", y.value)


if __name__ == "__main__":
    main()
