"""APMonitor tutorial 14: PID controller simulation / tuning."""

import numpy as np
from gekko import GEKKO


def build_model(remote=False):
    m = GEKKO(remote=remote)
    tf = 40
    m.time = np.linspace(0, tf, 2 * tf + 1)

    set_point = np.zeros(2 * tf + 1)
    set_point[3:40] = 2.0
    set_point[40:] = 5.0

    kc = 15.0
    tau_i = 2.0
    tau_d = 1.0
    op_bias = m.Const(value=0.0)

    op = m.Var(value=0.0)
    pv = m.Var(value=0.0)
    sp = m.Param(value=set_point)
    integral = m.Var(value=0.0)
    error = m.Intermediate(sp - pv)

    m.Equation(integral.dt() == error)
    m.Equation(op == op_bias + kc * error + (kc / tau_i) * integral - kc * tau_d * pv.dt())

    process_gain = 0.5
    process_tau = 10.0
    m.Equation(process_tau * pv.dt() + pv == process_gain * op)

    m.options.IMODE = 4
    return m, op, pv, sp


def main():
    m, op, pv, sp = build_model()
    m.solve(disp=False)
    print("final PV:", pv.value[-1])
    print("final SP:", sp.value[-1])


if __name__ == "__main__":
    main()
