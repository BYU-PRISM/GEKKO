"""Minimal model predictive control pattern with GEKKO."""

import numpy as np
from gekko import GEKKO


def main():
    m = GEKKO(remote=False)
    m.time = np.linspace(0, 20, 41)

    u = m.MV(value=0, lb=0, ub=100)
    u.STATUS = 1
    u.DCOST = 0.1
    u.DMAX = 10

    y = m.CV(value=0)
    y.STATUS = 1
    y.FSTATUS = 1
    y.SP = 40
    y.TAU = 5
    y.TR_INIT = 2

    m.Equation(5 * y.dt() == -y + u)

    m.options.IMODE = 6
    m.options.CV_TYPE = 2
    m.options.SOLVER = 3

    m.solve(disp=False)

    print("new MV move:", u.NEWVAL)
    print("predicted CV:", y.PRED)


if __name__ == "__main__":
    main()
