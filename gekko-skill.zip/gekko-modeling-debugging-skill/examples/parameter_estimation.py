"""Steady-state parameter estimation / regression with GEKKO."""

import numpy as np
from gekko import GEKKO


def main():
    x_data = np.array([0, 1, 2, 3, 4, 5], dtype=float)
    y_data = np.array([0.1, 0.2, 0.3, 0.5, 0.8, 2.0], dtype=float)

    m = GEKKO(remote=False)
    m.options.IMODE = 2
    m.options.SOLVER = 3

    x = m.Param(value=x_data)

    a = m.FV(value=0.5, lb=0, ub=5)
    a.STATUS = 1

    y = m.CV(value=y_data)
    y.FSTATUS = 1

    m.Equation(y == 0.1 * m.exp(a * x))

    m.solve(disp=False)

    print("fitted a:", a.value[0])
    print("model fit:", y.value)


if __name__ == "__main__":
    main()
