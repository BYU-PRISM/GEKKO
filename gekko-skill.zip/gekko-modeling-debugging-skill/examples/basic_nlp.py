"""Basic steady-state nonlinear optimization with GEKKO."""

from gekko import GEKKO


def main():
    m = GEKKO(remote=False)
    m.options.IMODE = 3
    m.options.SOLVER = 3

    x1 = m.Var(value=1, lb=1, ub=5)
    x2 = m.Var(value=5, lb=1, ub=5)
    x3 = m.Var(value=5, lb=1, ub=5)
    x4 = m.Var(value=1, lb=1, ub=5)

    m.Equation(x1 * x2 * x3 * x4 >= 25)
    m.Equation(x1**2 + x2**2 + x3**2 + x4**2 == 40)
    m.Minimize(x1 * x4 * (x1 + x2 + x3) + x3)

    m.solve(disp=False)

    print("x:", [v.value[0] for v in [x1, x2, x3, x4]])
    print("objective:", m.options.OBJFCNVAL)


if __name__ == "__main__":
    main()
