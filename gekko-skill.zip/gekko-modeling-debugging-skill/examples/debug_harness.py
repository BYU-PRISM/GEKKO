"""Reusable GEKKO diagnostic harness.

Import `solve_with_diagnostics` and call it instead of `m.solve()` when a model
is failing or returning unexpected results.
"""

from pathlib import Path


def print_gekko_diagnostics(m, max_chars=4000):
    """Print commonly useful files from the GEKKO model folder."""
    folder = Path(m.path)
    print("GEKKO model folder:", folder)

    for name in [
        "infeasibilities.txt",
        "APOPT.out",
        "ipopt.out",
        "results.json",
        "options.json",
    ]:
        path = folder / name
        if path.exists():
            print(f"\n--- {name} ---")
            print(path.read_text(errors="replace")[:max_chars])


def solve_with_diagnostics(m, *, disp=True, debug=1):
    """Solve a model and print local files if GEKKO raises an exception."""
    m.options.DIAGLEVEL = max(getattr(m.options, "DIAGLEVEL", 0), 1)
    try:
        m.solve(disp=disp, debug=debug)
    except Exception:
        print_gekko_diagnostics(m)
        raise
    return m
