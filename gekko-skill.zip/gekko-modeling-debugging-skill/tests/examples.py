"""Lightweight validation for skill examples.

The examples are compiled, not solved, so CI does not depend on GEKKO binaries,
remote solvers, or network availability.
"""

from pathlib import Path
import py_compile


def iter_python_examples(root):
    examples_root = root / "examples"
    yield from examples_root.rglob("*.py")


def test_examples_compile():
    root = Path(__file__).resolve().parents[1]
    for path in iter_python_examples(root):
        py_compile.compile(str(path), doraise=True)


if __name__ == "__main__":
    root = Path(__file__).resolve().parents[1]
    for path in iter_python_examples(root):
        py_compile.compile(str(path), doraise=True)
        print(f"compiled {path.relative_to(root)}")
