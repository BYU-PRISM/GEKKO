# GEKKO Modeling, Debugging, and Running Skill

This folder is a repository-ready assistant skill for the GEKKO project. It helps an agent build, debug, run, and explain GEKKO models, including the full range of problem classes covered by the APMonitor GEKKO Python tutorial page.

## Suggested repository placement

Add this folder to the GEKKO repository under one of these paths:

```text
skills/gekko-modeling-debugging/
```

or:

```text
.agent/skills/gekko-modeling-debugging/
```

## Contents

- `SKILL.md` — activation metadata and operational instructions.
- `docs/reference.md` — core GEKKO modeling reference.
- `docs/debug.md` — solver failure, infeasibility, and diagnostics workflow.
- `docs/patterns.md` — compact modeling patterns.
- `docs/tutorial.md` — routing guide for all APMonitor GEKKO Python tutorial problem types.
- `docs/src-map.md` — official documentation and source links.
- `examples/apmonitor_18/` — one compact Python template for each of the 18 APMonitor tutorial applications.
- `tests/examples.py` — syntax validation for all included Python examples.

## APMonitor tutorial coverage

The skill supports these tutorial-style problems:

1. Solver selection
2. Linear equation solving
3. Nonlinear equation solving
4. Cubic spline interpolation / spline optimization
5. Linear and polynomial regression
6. Nonlinear regression
7. Machine learning / neural network fitting
8. Differential equation simulation
9. Nonlinear programming
10. Mixed-integer nonlinear programming
11. Optimal control with an integral objective
12. Optimal control with an economic objective
13. Optimal control with final-time minimization
14. PID control simulation / tuning
15. Process simulation
16. Moving horizon estimation
17. Model predictive control
18. Debugging resources

## Validation

Run syntax checks from this folder:

```bash
python -m pytest tests/examples.py
```

or without pytest:

```bash
python tests/examples.py
```

The tests compile examples only. They do not solve models, so they can run in environments without GEKKO solver binaries or network access.

## Source links

- GEKKO source repository: https://github.com/BYU-PRISM/GEKKO
- GEKKO source archive: https://github.com/BYU-PRISM/GEKKO/archive/refs/heads/master.zip
- GEKKO documentation: https://gekko.readthedocs.io/en/latest/
- APMonitor GEKKO tutorial source: https://apmonitor.com/wiki/index.php/Main/GekkoPythonOptimization

## Attribution

Primary references:

- GEKKO documentation: https://gekko.readthedocs.io/en/latest/
- APMonitor GEKKO Python tutorials: https://apmonitor.com/wiki/index.php/Main/GekkoPythonOptimization
- GEKKO GitHub repository: https://github.com/BYU-PRISM/GEKKO
- GEKKO source archive: https://github.com/BYU-PRISM/GEKKO/archive/refs/heads/master.zip
